package org.example;

import java.text.DecimalFormat;

public class Money {
    private long cents;

    public Money(long cents) {
        this.cents = cents;
    }

    public double getDollars(){
        return cents / 100.00;
    }

    @Override
    public String toString(){
        DecimalFormat df = new DecimalFormat("$#,##0.00");
        return df.format(getDollars());
    }

    }



