package org.example;

import java.util.*;
import java.time.LocalDate;

public class ParkingOffice {

    private String name;
    private Address address;
    private List<Customer> customers = new ArrayList<>();
    private List<Car> cars = new ArrayList<>();
    private List<ParkingLot> lots = new ArrayList<>();
    private List<ParkingCharge> charges = new ArrayList<>();

    public ParkingOffice(String name, Address address){
        this.name = name;
        this.address = address;
    }

    //Registering customer - DO NOT TOUCH YET!!!!!!!!!!!!!!!!!!!!
    public Customer register(String customerId, String name, Address address, String phone) {
        Customer c = new Customer(customerId, name, address, phone);
        customers.add(c);
        return c;
    }

    //CAR
    public Car register(Customer c, String license, CarType type) {
        // For simplicity, just use today's date and the customer ID
        LocalDate registrationDate = LocalDate.now();
        String customerId = c.getCustomerId();

        Car car = new Car("CAR123", registrationDate, license, type, customerId);
        cars.add(car);
        return car;
    }

    //Customer lookup
    public Customer getCustomer(String name) {
        for (Customer c : customers) {
            if (c.getName().equalsIgnoreCase(name)) {
                return c;
            }
        }
        return null;
    }

    //adding charge
    public Money addCharge(ParkingCharge charge) {
        charges.add(charge);
        return charge.getAmount();
    }
}
