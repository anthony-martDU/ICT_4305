package org.example;

import java.util.ArrayList;
import java.util.List;

public class PermitManager {

    private List<ParkingPermit> permits = new ArrayList<>();

   //Creating a permit
    public ParkingPermit register(String permitId, Car car) {
        ParkingPermit permit = new ParkingPermit(permitId, car.getCarId(), car.getOwner());
        permits.add(permit);
        return permit;
    }

    public List<ParkingPermit> getPermits() {
        return permits;
    }

    public ParkingPermit getPermit(String permitId) {
        for (ParkingPermit p : permits) {
            if (p.getPermitId().equals(permitId)) {
                return p;
            }
        }
        return null;
    }
}
