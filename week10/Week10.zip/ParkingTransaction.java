package org.example;


import java.time.LocalDateTime;

public class ParkingTransaction {

    private String licensePlate;
    private double amountCharged;
    private LocalDateTime timeStamp;


    public ParkingTransaction(String licensePlate, double amountCharged) {
        this.licensePlate = licensePlate;
        this.amountCharged = amountCharged;
        this.timeStamp = LocalDateTime.now(); // timestamping
    }


    public String getLicensePlate() {
        return licensePlate;
    }

    public double getAmountCharged() {
        return amountCharged;
    }

    public LocalDateTime getTimeStamp() {
        return timeStamp;
    }

    @Override
    public String toString() {
        return "ParkingTransaction{" +
                "licensePlate='" + licensePlate + '\'' +
                ", amountCharged=" + amountCharged +
                ", timeStamp=" + timeStamp +
                '}';
    }
}

