package org.example;

import java.util.ArrayList;
import java.util.List;

public class ParkingOffice {

    private String name;
    private List<Customer> customers = new ArrayList<>();
    private List<Car> cars = new ArrayList<>();
    private List<ParkingLot> lots = new ArrayList<>();


    private PermitManager permitManager = new PermitManager();
    private TransactionManager transactionManager = new TransactionManager();

    public ParkingOffice(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }


    public Customer registerCustomer(String customerId, String name, Address address, String phone) {
        Customer c = new Customer(customerId, name, address, phone);
        customers.add(c);
        return c;
    }


    public ParkingPermit registerCar(Customer c, String carId, String license, CarType type) {
        Car car = new Car(carId, null, license, type, c.getCustomerId());
        cars.add(car);
        return permitManager.register("P001", car); // minimal, single permit ID
    }


    public ParkingTransaction park(ParkingPermit permit) {
        return transactionManager.park(permit);
    }

    public List<Customer> getCustomers() { return customers; }
    public List<Car> getCars() { return cars; }
    public List<ParkingLot> getLots() { return lots; }
}
