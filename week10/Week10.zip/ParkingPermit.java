package org.example;

public class ParkingPermit {

    private String permitId;   // unique permit number
    private String carId;      // car this permit belongs to
    private String customerId; // owner of the car

    public ParkingPermit(String permitId, String carId, String customerId) {
        this.permitId = permitId;
        this.carId = carId;
        this.customerId = customerId;
    }

    public String getPermitId() {
        return permitId;
    }

    public String getCarId() {
        return carId;
    }

    public String getCustomerId() {
        return customerId;
    }

    @Override
    public String toString() {
        return "ParkingPermit{" +
                "permitId='" + permitId + '\'' +
                ", carId='" + carId + '\'' +
                ", customerId='" + customerId + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ParkingPermit permit = (ParkingPermit) o;
        return permitId.equals(permit.permitId);
    }

    @Override
    public int hashCode() {
        return permitId.hashCode();
    }
}