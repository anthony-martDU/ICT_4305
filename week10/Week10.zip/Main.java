package org.example;

public class Main {

    public static void main(String[] args) {
        ParkingOffice office = new ParkingOffice("DU PARK");

        // Register customer
        Customer alice = office.registerCustomer("C001", "Alice", new Address("123 Main St", "Denver", "CO", "80202", "USA"), "555-1234");

        // Register car and create permit
        ParkingPermit permit = office.registerCar(alice, "CAR123", "ABC-123", CarType.SUV);

        // Park the car
        ParkingTransaction transaction = office.park(permit);

        // Output
        System.out.println("Customer IDs: " + office.getCustomers().stream().map(Customer::getCustomerId).toList());
        System.out.println("Permit ID: " + permit.getPermitId());
        System.out.println("Transaction: " + transaction);
    }
}
