package org.example;

import java.time.LocalDate;

public class ParkingTest {
    public static void main(String[] args) {

        //Address creation
        Address customerAddress = new Address("123 Main St", "APT 100", "Boise", "ID", "83704");
        Address lotAddress = new Address("500 Market St", null, "Denver", "CO", "80205");

        //Customer
        Customer customer = new Customer("CUST001", "John Doe", customerAddress, "208-555-5555");
        System.out.println("New Customer: " + customer);

        //Car Registration
        Car car1 = customer.register("ACB111", CarType.COMPACT);
        Car car2 = customer.register("XYZ123", CarType.SUV);

        //System down permit
        car1 = new Car("P001", LocalDate.now().plusMonths(1), "ABC111", CarType.COMPACT, customer.getCustomerId());
        car2 = new Car("P002", LocalDate.now().plusMonths(1), "XYZ123", CarType.SUV, customer.getCustomerId());

        //Lot creation
        ParkingLot parkingLot = new ParkingLot("Lot-A", lotAddress, 2);
        System.out.println("\nCreated Parking Lot: " + parkingLot);

        // car entries
        parkingLot.entry(car1);
        parkingLot.entry(car2);

        // Display final states
        System.out.println("\nFinal Customer Info:");
        System.out.println(customer);

        System.out.println("\nFinal Parking Lot Info:");
        System.out.println(parkingLot);
    }
}