package org.example;

import java.time.LocalDate;

public class Car {
    private String carId;
    private String permit;
    private LocalDate permitExpiration;
    private String license;
    private CarType type;
    private String owner; // customer and user Id

    public Car(String carId, LocalDate permitExpiration, String license, CarType type, String owner) {
        this.carId = carId; // --- NEW --- store the unique car ID
        this.permitExpiration = permitExpiration;
        this.license = license;
        this.type = type;
        this.owner = owner;
    }
    public String getCarId() { return carId; }
    public String getPermit() { return permit; }
    public LocalDate getPermitExpiration() { return permitExpiration; }
    public String getLicense() { return license; }
    public CarType getType() { return type; }
    public String getOwner() { return owner; }

    @Override
    public String toString() {
        return "Car{" +
                "carId='" + carId + '\'' +
                ", license='" + license + '\'' +
                ", type=" + type +
                ", permit='" + permit + '\'' +
                ", permitExpiration=" + permitExpiration +
                ", ownerId='" + owner + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Car car = (Car) o;
        return carId.equals(car.carId);
    }

    @Override
    public int hashCode() {
        return carId.hashCode();
    }

}
