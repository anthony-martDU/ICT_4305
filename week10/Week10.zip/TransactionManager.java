package org.example;

import java.util.ArrayList;
import java.util.List;

public class TransactionManager {

    private List<ParkingTransaction> transactions = new ArrayList<>();


    public ParkingTransaction park(ParkingPermit permit) {
        ParkingTransaction t = new ParkingTransaction(permit.getCarId(), 0.0); // 0 fee for simplicity
        transactions.add(t);
        return t;
    }

    public List<ParkingTransaction> getTransactions() {
        return transactions;
    }
}
