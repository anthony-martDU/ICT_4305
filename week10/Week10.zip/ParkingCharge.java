package org.example;

import java.security.PublicKey;
import java.time.Instant;

public class ParkingCharge {
    private String permitId;
    private String lotId;
    private Instant incurred;
    private Money amount;

    public ParkingCharge (String permitId, String lotId, Instant incurred, Money amount){
        this.permitId = permitId;
        this.lotId = lotId;
        this.incurred = incurred;
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "ParkingCharge [Permit ID=" + permitId +
                ", Lot ID=" + lotId +
                ", Incurred=" + incurred +
                ", Amount=" + amount + "]";
    }


    public Money getAmount() {
        return amount;
    }

}
